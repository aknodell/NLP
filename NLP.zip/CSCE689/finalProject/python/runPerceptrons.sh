python Perceptron.py ../data/untaggedReviews 3 10 >> ../outputs/perceptron_untagged_3_10.out
python Perceptron.py ../data/untaggedReviews 3 10 >> ../outputs/perceptron_untagged_3_10.out
python Perceptron.py ../data/untaggedReviews 3 10 >> ../outputs/perceptron_untagged_3_10.out
python Perceptron.py ../data/untaggedReviews 3 10 >> ../outputs/perceptron_untagged_3_10.out
python Perceptron.py ../data/untaggedReviews 3 10 >> ../outputs/perceptron_untagged_3_10.out
python Perceptron.py ../data/untaggedReviews 3 10 >> ../outputs/perceptron_untagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 > ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py ../data/taggedReviews 3 10 >> ../outputs/perceptron_tagged_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 > ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
python Perceptron.py -p ../data/taggedReviews 3 10 >> ../outputs/perceptron_posTag_3_10.out
